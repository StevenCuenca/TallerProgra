import javax.swing.JOptionPane;

public class Producto {
    public static void main(String[] args) {

        String nombreProducto = JOptionPane.showInputDialog("Ingrese el nombre del producto:");
        String precioStr = JOptionPane.showInputDialog("Ingrese el precio del producto:");
        String tieneIvaStr = JOptionPane.showInputDialog("¿El producto tiene IVA? (si/no):");

        double precio = Double.parseDouble(precioStr);
        double iva = 0.0;


        if (tieneIvaStr.equalsIgnoreCase("si")) {
            if (precio <= 500) {
                iva = 0.12;
            } else if (precio > 500 && precio <= 1500) {
                iva = 0.14;
            } else if (precio > 1500) {
                iva = 0.15;
            }
        }

        double valorIva = precio * iva;
        double precioFinal = precio + valorIva;

        String mensaje = "Datos del Producto:\n"
                + "Nombre del Producto: " + nombreProducto + "\n"
                + "Precio del Producto: $" + precio + "\n"
                + "Porcentaje de IVA: " + (iva * 100) + "%\n"
                + "Valor del IVA: $" + valorIva + "\n"
                + "Precio Final con IVA: $" + precioFinal;

        JOptionPane.showMessageDialog(null, mensaje);
    }
}
