import javax.swing.JOptionPane;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class Empleado {
    private String cedula;
    private String nombre;
    private String apellido;
    private String genero;
    private double salario;
    private LocalDate fechaNacimiento;
    private LocalDate fechaIngreso;


    public Empleado(String cedula, String nombre, String apellido, String genero, double salario, LocalDate fechaNacimiento, LocalDate fechaIngreso) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.apellido = apellido;
        this.genero = genero;
        this.salario = salario;
        this.fechaNacimiento = fechaNacimiento;
        this.fechaIngreso = fechaIngreso;
    }

    public void modificarSalario(double nuevoSalario) {
        this.salario = nuevoSalario;
        JOptionPane.showMessageDialog(null, "El salario ha sido actualizado a: $" + this.salario);
    }

    public int calcularEdad() {
        LocalDate hoy = LocalDate.now();
        Period edad = Period.between(this.fechaNacimiento, hoy);
        return edad.getYears();
    }

    public double calcularPrestaciones() {
        LocalDate hoy = LocalDate.now();
        Period antiguedad = Period.between(this.fechaIngreso, hoy);
        int anosAntiguedad = antiguedad.getYears();
        return (anosAntiguedad * this.salario) / 12;
    }

    public String mostrarDatos() {
        return "Datos del empleado:\n"
                + "Cédula: " + cedula + "\n"
                + "Nombre: " + nombre + " " + apellido + "\n"
                + "Género: " + genero + "\n"
                + "Salario: $" + salario + "\n"
                + "Fecha de Nacimiento: " + fechaNacimiento + "\n"
                + "Fecha de Ingreso: " + fechaIngreso;
    }

    public static void main(String[] args) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        String cedula = JOptionPane.showInputDialog("Ingrese la cédula del empleado:");
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del empleado:");
        String apellido = JOptionPane.showInputDialog("Ingrese el apellido del empleado:");
        String genero = JOptionPane.showInputDialog("Ingrese el género del empleado:");
        double salario = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el salario del empleado:"));
        LocalDate fechaNacimiento = LocalDate.parse(JOptionPane.showInputDialog("Ingrese la fecha de nacimiento (dd/MM/yyyy):"), formatter);
        LocalDate fechaIngreso = LocalDate.parse(JOptionPane.showInputDialog("Ingrese la fecha de ingreso (dd/MM/yyyy):"), formatter);

        Empleado empleado = new Empleado(cedula, nombre, apellido, genero, salario, fechaNacimiento, fechaIngreso);

        JOptionPane.showMessageDialog(null, empleado.mostrarDatos());

        double nuevoSalario = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el nuevo salario del empleado:"));
        empleado.modificarSalario(nuevoSalario);

        int edad = empleado.calcularEdad();
        JOptionPane.showMessageDialog(null, "La edad del empleado es: " + edad + " años.");

        double prestaciones = empleado.calcularPrestaciones();
        JOptionPane.showMessageDialog(null, "Las prestaciones del empleado son: $" + prestaciones);
    }
}
