import javax.swing.JOptionPane;

public class Vehiculo {
    public static void main(String[] args) {

        String numeroMotor = JOptionPane.showInputDialog("Ingrese el número de motor del vehículo:");
        String numeroVentanas = JOptionPane.showInputDialog("Ingrese el número de ventanas del vehículo:");
        String cantidadPuertas = JOptionPane.showInputDialog("Ingrese la cantidad de puertas del vehículo:");
        String marca = JOptionPane.showInputDialog("Ingrese la marca del vehículo:");
        String modelo = JOptionPane.showInputDialog("Ingrese el modelo del vehículo:");
        String kilometrajeInicialStr = JOptionPane.showInputDialog("Ingrese el kilometraje inicial del vehículo:");
        String kilometrajeFinalStr = JOptionPane.showInputDialog("Ingrese el kilometraje final del vehículo:");

        double kilometrajeInicial = Double.parseDouble(kilometrajeInicialStr);
        double kilometrajeFinal = Double.parseDouble(kilometrajeFinalStr);

        double kilometrosRecorridos = kilometrajeFinal - kilometrajeInicial;

        String mensaje = "Datos del Vehículo:\n"
                + "Número de Motor: " + numeroMotor + "\n"
                + "Número de Ventanas: " + numeroVentanas + "\n"
                + "Cantidad de Puertas: " + cantidadPuertas + "\n"
                + "Marca: " + marca + "\n"
                + "Modelo: " + modelo + "\n"
                + "Kilometraje Inicial: " + kilometrajeInicial + " km\n"
                + "Kilometraje Final: " + kilometrajeFinal + " km\n"
                + "Kilómetros Recorridos: " + kilometrosRecorridos + " km";

        JOptionPane.showMessageDialog(null, mensaje);
    }
}
